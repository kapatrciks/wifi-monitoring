<div class="wrapper">

    <div class="sidebar">
        <!-- <div class="profile">
            <img src="tssk.jpg" alt="profile_picture">
            <h3><?php
                echo $_SESSION['admin_fname'] . ' ' . $_SESSION['admin_lname']; ?></h3>
            <p>Position</p>
        </div> -->
        <ul>
            <li>
                <a href="Dashboard.php">
                    <span class="icon"><i class="fa-solid fa-chart-pie"></i></span>
                    <span class="item">Dashboard</span>
                </a>
            </li>

            <li>
                <a href="WifiData.php">
                    <span class="icon"><i class="fa-solid fa-map-location-dot"></i></span>
                    <span class="item">Map</span>
                </a>
            </li>
            <li>
                <a href="#">
                    <span class="icon"><i class="fa-solid fa-clipboard"></i></span>
                    <span class="item">Reports</span>
                </a>
            </li>
            <li>
                <a href="AdminManagement.php">
                    <span class="icon"><i class="fa-solid fa-users"></i></span>
                    <span class="item">Admin Management</span>
                </a>
            </li>

            <li>
                <a href="process/logout.php" id="logout">
                    <span class="icon"><i class="fa-solid fa-arrow-right-from-bracket"></i></span>
                    <span class="item">Logout</span>
                </a>
            </li>
        </ul>
    </div>
</div>