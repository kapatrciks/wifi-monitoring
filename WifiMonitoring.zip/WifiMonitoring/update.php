
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
   

    <link rel="stylesheet" href="css/update.css">
</head>
<body>
            

            <form action ="process/insert-data/updatehandler.inc.php" method = "post">

                <div class="up-container">



                    <div class="up-child">

                    <span>First Name</span> <input type= "text" name="fname" placeholder = "First name"/> 
                    <span>Last Name</span><input type= "text" name="lname" placeholder = "Last name"/>
                    <span>Position</span><input type= "text" name="position" placeholder = "Position"/>
                    <span>Username</span><input type= "text" name="username" placeholder = "Username"/>
                    <span>Password</span><input type= "text" name="password" placeholder = "Password"/>

                    <button>UPDATE</button>
                    </div> 
                        


                    
                </div>
                

            </form>