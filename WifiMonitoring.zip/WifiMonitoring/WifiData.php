<?php


session_start();
if (empty($_SESSION['admin_id'])) {
    header('Location: WifiMonitoring.php');
}


include 'process/classes/model.class.php';
include 'process/classes/view-wifi.class.php';

$wifi_info = new ViewWifi();
$wifi_data = $wifi_info->collectWifi();
$lnglat = $wifi_info->collectWifi();
$del = $wifi_info->collectWifi();

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/wifi.css">
    <link rel="stylesheet" href="css/sidenav.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <script src='https://api.mapbox.com/mapbox-gl-js/v3.1.2/mapbox-gl.js'></script>
    <link href='https://api.mapbox.com/mapbox-gl-js/v3.1.2/mapbox-gl.css' rel='stylesheet' />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js" integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
</head>

<body>



    <div class="wifi-container">
        <div class="navcontainer">
            <?php
            include 'include/sidenav.php';
            ?>
        </div>
        <div class="main">
            <div class="wifi-sider">
                <h2>Wifi List</h2>
                <div class="search-wifi">
                    <div class="input-data">
                        <input type="text" id="search-wifi" placeholder="sitename or location...">
                        <label for="search-wifi"><i class="fa-solid fa-magnifying-glass"></i></label>
                    </div>

                    <div id="wifi-list"></div>

                </div>
            </div>
            <div class="wifi-content">
                <div class="wifi-option">
                    <button type="button" id="reset-location" class="header-btn"><i class="fa-solid fa-location-crosshairs"></i></button>
                    <a href="AddWifi.php" id="add-location" class="header-btn"><i class="fa-solid fa-plus"></i>add location</a>
                    <button type="button" id="delete-location" class="header-btn"><i class="fa-solid fa-trash"></i>delete</button>
                </div>
                <div id='map'></div>
            </div>

        </div>
        <div class="delete-container" style="display:none">

            <div class="delete-content">
                <div class="delete-header">
                    <h1>Delete data</h1>
                    <button type="button" id="exit-delete"><i class="fa-solid fa-xmark"></i></button>
                </div>
                <div class="search-container">
                    <div class="search-delete">
                        <input type="text" id="search-delete" placeholder="sitename or location...">
                        <label for="search-delete"><i class="fa-solid fa-magnifying-glass"></i></label>
                    </div>
                </div>
                <form action="process/delwifi.php" method="post" class="constent-data-delete">
                    <div id="delete-table"></div>
                    <script>
                        $(document).ready(function() {

                            $.ajax({
                                url: "process/search-delete.php",
                                method: "POST",
                                success: function(data) {
                                    $('#delete-table').html(data);
                                }
                            })
                            $('#search-delete').keyup(function() {
                                var data = $(this).val();

                                if (data != '') {
                                    $.ajax({
                                        url: "process/search-delete.php",
                                        method: "POST",
                                        data: {
                                            data: data
                                        },
                                        success: function(data) {
                                            $('#delete-table').html(data);
                                        }
                                    })
                                }

                            });




                        });
                    </script>
                    <div class="del-btn">
                        <input type="submit" value="delete">
                    </div>
                </form>

            </div>

        </div>

        <script>
            $(document).ready(function() {

                // show del
                $('#delete-location').click(function() {
                    $('.delete-container').fadeIn(300);
                });

                // exit del
                $('#exit-delete').click(function() {
                    $('.delete-container').fadeOut(300);
                });
            });
        </script>


    </div>



</body>



<script>
    $(document).ready(function() {

        $.ajax({
            url: "process/search-wifi.php",
            method: 'POST',
            success: function(data) {
                $('#wifi-list').html(data);
            }
        })

        $('#search-wifi').keyup(function() {
            var inputData = $('#search-wifi').val();

            if (inputData != '') {
                $.ajax({
                    url: "process/search-wifi.php",
                    method: 'POST',
                    data: {
                        search: inputData
                    },
                    success: function(data) {
                        $('#wifi-list').html(data);
                    }
                })
            } else {
                $.ajax({
                    url: "process/search-wifi.php",
                    method: 'POST',
                    success: function(data) {
                        $('#wifi-list').html(data);
                    }
                })
            }
        });


    });
</script>







<script>
    mapboxgl.accessToken = 'pk.eyJ1IjoiamFtZXNhbGZyZWFkIiwiYSI6ImNsc3dnemd3bTB4anYyaXF0OXpuejQycmEifQ.MBBUmoFbzNIiDH0zuXcJjg';
    const map = new mapboxgl.Map({
        container: 'map', // container ID
        style: 'mapbox://styles/mapbox/navigation-day-v1', // style URL
        center: [121.235504, 14.342896], // starting position [lng, lat]
        zoom: 8, // starting zoom
        projection: 'globe'
    });



    document.getElementById('reset-location').addEventListener('click', () => {
        map.flyTo({
            center: [121.235504, 14.342896],
            zoom: 8,
        })
    });





    <?php
    while ($row = $lnglat->fetch()) {
        if (!empty($row['Longitude'])) {
    ?>

            // hindi ko pa na seset pag hindi terminated
            var popup = new mapboxgl.Popup({
                offset: 25
            }).setHTML(
                `<div class="marker-cotainer">
        <div class="info">
            <h3>Sitename : <?php echo $row['SITENAME']; ?></h3>
            <p>Location : <?php echo $row['LOCATION']; ?></p>
            <p>Locality Name : <?php echo $row['Locality Name']; ?></p>
            <p>Site Code : <?php echo $row['SITE CODE']; ?></p>
            <div class="coordinate"> Coordinate :<div class="long"><?php echo 'long : ' . $row['Longitude']; ?></div><div class="lat"><?php echo 'lat : ' . $row['Latitude']; ?></div></div>

            



            <div class="status">Status :<div class="contract-status <?php if (strtolower($row['CONTRACT STATUS']) == 'active') {
                                                                        echo "status-active";
                                                                    } ?>"><?php echo $row['CONTRACT STATUS'] ?></div></div>







        </div>

        <form action="WifiInfo.php" method="post">
            <input type="hidden" name="Longitude" value="<?php echo $row['Longitude']; ?>">
            <input type="hidden" name="Latitude" value="<?php echo $row['Latitude']; ?>">
            <input type="submit" value="view details">
        </form>
    </div>`
            );

            var setColor = '<?php
                            if (strtoupper($row['CONTRACT STATUS']) != 'TERMINATED') {
                                echo '#00ff04';
                            } else {
                                echo '#ff0000';
                            }
                            ?>';


            new mapboxgl.Marker({
                    color: setColor,
                    scale: .8,
                })
                .setPopup(popup)
                .setLngLat([<?php echo $row['Latitude'] ?>, <?php echo $row['Longitude'] ?>])
                .addTo(map);


    <?php
        }
    }
    ?>

    map.on('load', () => {
        map.setFog({});
    });
</script>

</html>