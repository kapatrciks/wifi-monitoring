<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.cdnfonts.com/css/poppins" rel="stylesheet">
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
    <link rel="stylesheet" href="css/login.css">
    <title>Free Wifi</title>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js" integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
</head>

<body>
    <div class="landing-page">
        <div id="image-frame">
            <img src="img/FREE-WIFI.jpg" alt="logo" width="100%" height="100%" id="img-1">
            <img src="img/bg_fw.jpg" alt="logo" width="100%" height="100%" id="img-2" style="display:none;">
            <img src="img/cellphone.png" alt="logo" width="100%" height="100%" id="img-3" style="display:none;">
            <img src="img/dictfreewifi.png" alt="logo" width="100%" height="100%" id="img-4" style="display:none;">
            <img src="img/freewifiphone.webp" alt="logo" width="100%" height="100%" id="img-5" style="display:none;">
        </div>

        <div class="login_form">
            <form action="process/login.php" method="post">
                <h2>Login</h2>
                <div class="user-input">
                    <i class="uil uil-envelope-alt email"></i>
                    <input type="text" name="username" placeholder="username" required id="" />
                </div>
                <div class="user-input">
                    <i class="uil uil-lock password"></i>
                    <input type="password" name="password" placeholder="password" required id="" />
                    <i class="uil uil-eye-slash pw_hide"></i>
                </div>
                <input type="submit" value="Login">
            </form>
            <a href="https://dict.gov.ph/" target="_blank" class="dict">
                <img src="img/dict.png" alt="dict" width="60px" height="60px">
            </a>

        </div>


    </div>
    <script src="javascript/login.js"></script>

    <script>
        $(document).ready(function() {
            var incre = 0;
            setInterval(() => {
                incre++;
                if (incre != 6) {
                    if (incre == 2) {
                        $('#img-1').css('display', 'none');
                        $('#img-2').fadeIn(2000);
                    }
                    if (incre == 3) {
                        $('#img-2').css('display', 'none');
                        $('#img-3').fadeIn(2000);
                    }
                    if (incre == 4) {
                        $('#img-3').css('display', 'none');
                        $('#img-4').fadeIn(2000);
                    }
                    if (incre == 5) {
                        $('#img-4').css('display', 'none');
                        $('#img-5').fadeIn(2000);
                    }

                } else {
                    incre = 0;
                    $('#img-5').css('display', 'none');
                    $('#img-1').fadeIn(2000);
                }

            }, 5000);
        });
    </script>
</body>

</html>