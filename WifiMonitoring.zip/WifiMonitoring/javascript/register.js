
function generateCredentials() {
    // Get values from the input fields
    var firstName = document.getElementsByName("firstname")[0].value;
    var lastName = document.getElementsByName("lastname")[0].value;

    // Generate username and password
    var username = firstName.toLowerCase() + lastName.toLowerCase();
    var password = generateRandomPassword();

    // Set values to the readonly fields
    document.getElementsByName("username")[0].value = username;
    document.getElementsByName("password")[0].value = password;
}

function generateRandomPassword() {
    // You can implement your logic for generating a random password here
    // For simplicity, let's generate a random string with 8 characters
    var characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    var password = "";
    for (var i = 0; i < 8; i++) {
        password += characters.charAt(Math.floor(Math.random() * characters.length));
    }
    return password;
}





// Function to get URL parameters
function getUrlParameter(name) {
    name = name.replace(/[[]/, "\\[").replace(/[\]]/, "\\]");
    var regex = new RegExp("[\\?&]" + name + "=([^&#]*)");
    var results = regex.exec(location.search);
    return results === null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
}

// Check if the URL parameter is 'success=update_successful'
var successParam = getUrlParameter('success');
if (successParam === 'update_successful') {
    // Show the success container and initiate fade-in after a delay
    var container = document.getElementById('successContainer');

    // Remove display: none; to make the container initially visible
    container.style.opacity = '1';

    // Trigger the fade-in by changing opacity to 1 after a delay
    setTimeout(function () {
        container.style.opacity = '1';
    }, 1000); // Delay of 1000 milliseconds (1 second)
}

