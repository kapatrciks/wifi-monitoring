<?php
session_start();
if (empty($_SESSION['admin_id'])) {
    header('Location: WifiMonitoring.php');
}

include('process/classes/model.class.php');
include('process/classes/view-wifi.class.php');

$wifiData = new ViewWifi();

$rawdata = $wifiData->collectWifi();

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="css/sidenav.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <script src='https://api.mapbox.com/mapbox-gl-js/v3.1.2/mapbox-gl.js'></script>
    <link href='https://api.mapbox.com/mapbox-gl-js/v3.1.2/mapbox-gl.css' rel='stylesheet' />
    <link rel="stylesheet" href="css/dashboard.css">\






    <style>
        .mapboxgl-ctrl-bottom-left {
            display: none;
        }
    </style>
</head>

<body>


    <div class="main-container">
        <div class="navcontainer">
            <?php
            include 'include/sidenav.php';
            ?>
        </div>
        <div class="main">
            <!-- 
            <div class="searchbar2">
                <input type="text" name="" id="" placeholder="Search">
                <div class="searchbtn">
                    <img src="https://media.geeksforgeeks.org/wp-content/uploads/20221210180758/Untitled-design-(28).png" class="icn srchicn" alt="search-button">
                </div>
            </div> -->

            <div class="box-container">

                <div class="box box1">
                    <div class="text">
                        <h2 class="topic-heading">950</h2>
                        <i class="fa-solid fa-signal fa-2xl"></i>
                    </div>
                    <h2 class="topic">Active Sites</h2>
                </div>

                <div class="box box2">
                    <div class="text">
                        <h2 class="topic-heading">1549</h2>
                        <i class="fa-solid fa-ban fa-2xl"></i>
                    </div>
                    <h2 class="topic">Terminated Sites</h2>
                </div>

                <div class="box box3">
                    <div class="text">
                        <h2 class="topic-heading">174</h2>
                        <i class="fa-solid fa-rotate-left fa-2xl"></i>
                    </div>
                    <h2 class="topic">Reactivated Sites</h2>
                </div>

                <div class="box box4">
                    <div class="text">
                        <h2 class="topic-heading">2673</h2>
                        <i class="fa-regular fa-circle-check fa-2xl"></i>
                    </div>
                    <h2 class="topic">Established Sites</h2>
                </div>
            </div>

            <!-- <div class="report-container">
                <div class="report-header">
                    <h1 class="recent-Articles">Record</h1>
                    <button class="view">View All</button>
                </div>

                <div class="report-body">
                    <table>
                        <tr>
                            <th> Hello </th>
                        </tr>

                    </table>



                </div>
            </div> -->

            <!-- end -->

            <div class="map-container">
                <div class="map-header">
                    <h1 class="map-Articles">Map</h1>
                </div>
                <a href="WifiData.php">
                    <div id='map'></div>
                </a>

            </div>
        </div>
    </div>

    <script src="./index.js"></script>





</body>
<script>
    mapboxgl.accessToken = 'pk.eyJ1IjoiamFtZXNhbGZyZWFkIiwiYSI6ImNsc3dnemd3bTB4anYyaXF0OXpuejQycmEifQ.MBBUmoFbzNIiDH0zuXcJjg';
    const map = new mapboxgl.Map({
        container: 'map', // container ID
        style: 'mapbox://styles/mapbox/navigation-day-v1', // style URL
        center: [121.150360, 14.207145], // starting position [lng, lat]
        zoom: 7, // starting zoom
        projection: 'globe'
    });

    <?php

    while ($row = $rawdata->fetch()) {
        if (!empty($row['Longitude'])) {
    ?>

            console.log(<?php echo $row['Latitude'] ?>);

            var <?php echo 'here'; ?> = new mapboxgl.Popup({
                offset: 25
            }).setText("<?php echo $row['SITENAME']; ?>");


            var setColor = '<?php
                            if (strtoupper($row['CONTRACT STATUS']) != 'TERMINATED') {
                                echo '#00ff04';
                            } else {
                                echo '#ff0000';
                            }
                            ?>';

            new mapboxgl.Marker({
                    color: setColor,
                    scale: .8,
                })
                .setLngLat([<?php echo $row['Latitude'] ?>, <?php echo $row['Longitude'] ?>])
                .addTo(map);

    <?php
        }
    }

    ?>
</script>

</html>