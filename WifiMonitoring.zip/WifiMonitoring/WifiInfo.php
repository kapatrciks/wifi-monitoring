<?php
if ($_SERVER['REQUEST_METHOD']) {
    session_start();

    if (isset($_POST['Longitude']) && isset($_POST['Latitude'])) {

        $_SESSION['Longitude'] = htmlspecialchars($_POST['Longitude']);
        $_SESSION['Latitude'] = htmlspecialchars($_POST['Latitude']);

        $long = htmlspecialchars($_POST['Longitude']);
        $lat = htmlspecialchars($_POST['Latitude']);
    } elseif (isset($_SESSION['Longitude']) && isset($_SESSION['Latitude'])) {
        $long = htmlspecialchars($_SESSION['Longitude']);
        $lat = htmlspecialchars($_SESSION['Latitude']);
    } else {
        header('location: WifiData.php');
        exit();
    }



    if (empty($long) && empty($lat)) {
        header('location: WifiData.php');
        exit();
    }

    if (!preg_match('/\d/', $long) && !preg_match('/\d/', $lat)) {
        header('location: WifiData.php');
        exit();
    }

    include 'process/classes/model.class.php';
    include 'process/classes/view-wifi.class.php';

    $wifiInfo = new ViewWifi();

    $wifiData = $wifiInfo->longLatDataView($long, $lat);

    $row = $wifiData->fetch();
?>
    <!DOCTYPE html>
    <html lang="en">

    <head>S
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Document</title>
        <link rel="stylesheet" href="css/wifi.css">
        <link rel="stylesheet" href="css/sidenav.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
        <script src='https://api.mapbox.com/mapbox-gl-js/v3.1.2/mapbox-gl.js'></script>
        <link href='https://api.mapbox.com/mapbox-gl-js/v3.1.2/mapbox-gl.css' rel='stylesheet' />
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js" integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    </head>

    <body>
        <div class="wifi-container">
            <div class="navcontainer">
                <?php
                include 'include/sidenav.php';
                ?>
            </div>
            <div class="update-main">

                <div class="header-update">
                    <a href="WifiData.php" class="back-btn"><i class="fa-solid fa-arrow-left"></i></a>
                </div>
                <div class="body-update">
                    <div class="form-header">
                        <h1>Update Wifi Site</h1>

                        <p>Integrated date : <?php echo $row['INTEGRATED DATE'] ?></p>

                    </div>
                    <form action="process/updatewifi.php" method="post">

                        <div class="update-form">
                            <label for="">Locality Name</label>
                            <input type="text" value="<?php echo $row['Locality Name'] ?>" name="localityName">
                        </div>
                        <div class="update-form">
                            <label for="">Site Code</label>
                            <input type="text" value="<?php echo $row['SITE CODE'] ?>" name="siteCode">
                        </div>
                        <div class="update-form">
                            <label for="">Location</label>
                            <input type="text" value="<?php echo $row['LOCATION'] ?>" name="location">
                        </div>
                        <div class="update-form">
                            <label for="">Site name</label>
                            <input type="text" value="<?php echo $row['SITENAME'] ?>" name="sitename">
                        </div>
                        <div class="update-form">
                            <label for="">Contract status</label>
                            <input type="text" value="<?php echo $row['CONTRACT STATUS'] ?>" name="contractstatus">
                        </div>
                        <div class="update-form">
                            <label for="">End of Contract</label>
                            <input type="text" placeholder="optional..." value="<?php echo $row['END OF CONTRACT'] ?>" name="endofContract">
                        </div>
                        <div class="update-form">
                            <label for="">Cluster</label>
                            <input type="text" value="<?php echo $row['Cluster'] ?>" name="cluster">
                        </div>
                        <div class="update-form">
                            <label for="">CMS Tender Code</label>
                            <input type="text" value="<?php echo $row['CMS TENDER CODE'] ?>" name="tenderCode">
                        </div>
                        <div class="update-form">
                            <label for="">Category</label>
                            <input type="text" value="<?php echo $row['CATEGORY'] ?>" name="category">
                        </div>
                        <div class="update-form">
                            <label for="">Site type</label>
                            <input type="text" value="<?php echo $row['SITE TYPE'] ?>" name="sitetype">
                        </div>

                        <!-- button -->
                        <div class="submit-form">
                            <input type="submit" value="update data">
                        </div>
                    </form>
                </div>







            </div>
        </div>
    </body>

    </html>
<?php
}
?>