<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="dashboard.css">
    <link href="https://fonts.cdnfonts.com/css/poppins" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <title>Dashboard</title>
</head>

<body>

    <div class="news">
        <ul>
            <li>
                Ang
            </li>
            <li>
                lobo ay na Offline!
            </li>
            <li>
                soro soro plaza!
            </li>
            <li>
                cuta!
            </li>
            <li class="test">
                Ang
            </li>
            <li>
                lobo ay na Offline!
            </li>
            <li>
                soro soro plaza!
            </li>
            <li>
                cuta!
            </li>
        </ul>
    </div>
</body>

</html>