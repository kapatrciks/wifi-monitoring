<?php 


include 'process/classes/model.class.php';
include 'process/classes/view-wifi.class.php';

$data = new ViewWifi();

$wifireport = $data->collectWifi();


?>






<!DOCTYPE html>
<html lang="en">
    <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">

            <link rel="stylesheet" href="css/report.css">
            <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css" />

            <script src="https://kit.fontawesome.com/e6356a1101.js" crossorigin="anonymous"></script>
            <link href="https://fonts.cdnfonts.com/css/poppins" rel="stylesheet">

            <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
            <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
            <script type="text/javascript" src="https://cdn.jsdelivr.net/momentjs/latest/moment.min.js"></script>
            <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.js"></script>




       
        <title>Free Wifi Report</title>
    </head>
    <body>
        <header>
            <div class="table-header">
                <h1>Reports</h1>
            </div>
        </header>
        

        <div class="container">

                        <div class="headcont">
                                    <div class="searchbar">

                                        <input type="text" class="input" placeholder="Search..." id="searchInput" >
                                            <i class="fas fa-search"></i>

                                    </div>
                                    
                                    <div class="print">
                                            <button onclick="window.printTable()" class="print-button" ><span class="print-icon"></span></button>
                                    </div>

                                    <div id="reportrange" style="margin-left: 25%; position:absolute; background: #fff; cursor: pointer; padding: 5px 20px; border: 1px solid #ccc; width: 350px">
                                        <i class="fa fa-calendar"></i>&nbsp;
                                        <span></span> <i class="fa fa-caret-down"></i>
                                    </div>

                                  
                        </div>


        <br>
           

                <div class="recordForm">
                    <div class="scroll">
                        <table>
                            <tr>
                                <th>Site Code</th>
                                <th>Mac Address</th>
                                <th>Region</th>
                                <th>Province</th>
                                <th>Congressional District</th>
                                <th>Locality Name</th>
                                <th>Site Code/ ID</th>
                                <th>Location</th>
                                <th>Site Name</th>
                                <th>Longitude</th>
                                <th>Latitude</th>
                                <th>Status</th>
                                <th>Integrated Date</th>
                                <th>End of Contract</th>
                                <th>Cluster</th>
                                <th>CMS Tender Code/Contract</th>
                                <th>Category</th>
                                <th>Site Type</th>
                            </tr>

                            <?php
                        while ($row =$wifireport->fetch()) {
                            ?>
                          <tr class="data-row">
                                <td><?php echo $row['SITE CODE']; ?></td>
                                <td><?php echo $row['MAC ADDRESS']; ?></td>
                                <td><?php echo $row['Region']; ?></td>
                                <td><?php echo $row['Province']; ?></td>
                                <td><?php echo $row['Congressional  District']; ?></td>
                                <td><?php echo $row['Locality Name']; ?></td>
                                <td><?php echo $row['SITE CODE ID']; ?></td>
                                <td><?php echo $row['LOCATION']; ?></td>
                                <td><?php echo $row['SITENAME']; ?></td>
                                <td><?php echo $row['Longitude']; ?></td>
                                <td><?php echo $row['Latitude']; ?></td>
                                <td><?php echo $row['CONTRACT  STATUS']; ?></td>
                                <td><?php echo $row['INTEGRATED  DATE']; ?></td>
                                <td><?php echo $row['END OF CONTRACT']; ?></td>
                                <td><?php echo $row['Cluster']; ?></td>
                                <td><?php echo $row['CMS TENDER  CODE CONTRACT']; ?></td>
                                <td><?php echo $row['CATEGORY']; ?></td>
                                <td><?php echo $row['SITE  TYPE']; ?></td>
                          </tr>
                          <?php 
                          }
                          
                          ?>
                        </table>
                    </div>
                </div>
            </div>
 
      


       
           
<script src="javascript/report.js"></script>



       


    </body>
</html>