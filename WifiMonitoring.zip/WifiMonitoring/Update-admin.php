<?php

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    $admin_id = htmlspecialchars($_POST['admin_id']);
    include 'process/classes/model.class.php';
    include 'process/classes/admin-list-view.class.php';

    $data = new ViewAdmin();

    $wifireport = $data->callAdmin($admin_id);


    $row = $wifireport->fetch();

    $currentDate = date('Y-m-d'); // Format: Year-Month-Day

?>





    <html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=, initial-scale=1.0">
    </head>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="css/sidenav.css">
    <link rel="stylesheet" href="css/update-admin.css">
    <link rel="stylesheet" href="css/update.css">

    <body>
        <div class="admin-container">
            <div class="navcontainer">
                <?php
                include 'include/sidenav.php';
                ?>
            </div>


            <div class="main-admin">

                <div class="adim-header">
                    <div class="arrow"> <a href="AdminManagement.php" class="back-btn"><i class="fa-solid fa-arrow-left"></i></a>
                        </button>
                    </div>
                    <div class="head-name">
                        <h1>Update Account</h1>
                    </div>
                </div>


                <div class="admin-body">
                    <form action="process/insert-data/updatehandler.inc.php" method="post">

                        <div class="up-container">

                            <div class="up-child">
                                <br><br>
                                <span>First Name</span> <input type="text" name="fname" value="<?php echo $row['admin_fname']; ?>" required />
                                <span>Last Name</span><input type="text" name="lname" value="<?php echo $row['admin_lname']; ?> " required />
                                <span>Position</span><input type=" text" name="position" value="<?php echo $row['position']; ?>" required />
                                <span>Username</span><input type=" text" name="username" value="<?php echo $row['admin_uname']; ?>" required />
                                <span>Password</span><input type=" text" name="password" placeholder="Type New Password" />
                                <input type="hidden" name="value" value="<?php echo $row['admin_id']; ?>" />
                                <input type="hidden" name="up_date" value="<?php echo $currentDate; ?>" />

                                <button>UPDATE</button>
                            </div>



                        </div>



                    </form>

                </div>



            </div>



        </div>

    </body>



    </html>

<?php } ?>