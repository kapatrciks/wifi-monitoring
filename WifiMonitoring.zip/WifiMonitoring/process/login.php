<?php
if ($_SERVER['REQUEST_METHOD']) {

    $username = htmlspecialchars($_POST['username']);
    $password = htmlspecialchars($_POST['password']);

    include 'classes/model.class.php';
    include 'classes/login-view.class.php';
    include 'classes/login-control.class.php';

    $login = new LoginControl($username, $password);

    var_dump($login->loginAttr());
}
