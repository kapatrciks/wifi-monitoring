<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $firstname = htmlspecialchars($_POST["firstname"]);
    $lastname = htmlspecialchars($_POST["lastname"]);
    $position = htmlspecialchars($_POST["position"]);

    // $admin_id = htmlspecialchars($_POST["admin_id"]);
    // $location = htmlspecialchars($_POST["location"]);
    // $sitecode = htmlspecialchars($_POST["sitecode"]);
    // $sitename = htmlspecialchars($_POST["sitename"]);

    // generated user name and password
    $usernames = htmlspecialchars($_POST["username"]);
    $passwords = htmlspecialchars($_POST["password"]);

    try {
        include "dbh.inc.php";

        $query = "INSERT INTO admin (admin_fname, admin_lname, admin_uname, position, admin_password) VALUES (?, ?, ?, ?, ?);";

        $stmt = $pdo->prepare($query);

        $pass = password_hash($passwords, PASSWORD_DEFAULT);

        $stmt->execute([$firstname, $lastname, $usernames, $position, $pass]);

        $pdo = null;
        $stmt = null;

        header("admin_account.php");
        die();
    } catch (PDOException $e) {
        die("Query Failed: " . $e->getMessage());
    }
} else {
    header("admin_account.php");
}
