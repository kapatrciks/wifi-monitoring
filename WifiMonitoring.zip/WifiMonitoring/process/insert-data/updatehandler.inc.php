<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $first = $_POST["fname"];
    $last = $_POST["lname"];
    $pos = $_POST["position"];
    $user = $_POST["username"];
    $password = $_POST["password"];
    $value = $_POST["value"];
    $up_date = $_POST["up_date"];




    try {
        include "dbh.inc.php";

        $query = "UPDATE admin SET admin_fname = :fname, admin_lname = :lname, position = :pos,
                                     admin_uname = :uname, admin_password = :passw, update_count = :up_date  WHERE admin_id = :admin_id ";


        $stmt = $pdo->prepare($query);

        $pass = password_hash($password, PASSWORD_DEFAULT);

        $stmt->bindParam(":fname", $first);
        $stmt->bindParam(":lname", $last);
        $stmt->bindParam(":pos", $pos);
        $stmt->bindParam(":uname", $user);
        $stmt->bindParam(":passw", $pass);
        $stmt->bindParam(":admin_id", $value);
        $stmt->bindParam(":up_date", $up_date);

        $stmt->execute();

        $pdo = null;
        $stmt = null;

        header("Location: ../../AdminManagement.php?success=update_successful");
        die();
    } catch (PDOException $e) {
        die("Query Failed: " . $e->getMessage());
    }
} else {
    header("AdminManagement.php?error=failed_successfully");
}
