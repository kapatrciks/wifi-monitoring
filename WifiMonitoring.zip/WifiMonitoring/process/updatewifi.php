<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $localityName = htmlspecialchars($_POST['localityName']);
    $siteCode = htmlspecialchars($_POST['siteCode']);
    $location = htmlspecialchars($_POST['location']);
    $sitename = htmlspecialchars($_POST['sitename']);
    $contractstatus = htmlspecialchars($_POST['contractstatus']);
    $endofContract = htmlspecialchars($_POST['endofContract']);
    $cluster = htmlspecialchars($_POST['cluster']);
    $tenderCode = htmlspecialchars($_POST['tenderCode']);
    $category = htmlspecialchars($_POST['category']);
    $sitetype = htmlspecialchars($_POST['sitetype']);


    include 'classes/model.class.php';
    include 'classes/view-wifi.class.php';
    include 'classes/update-wifi-control.class.php';

    $update = new UpdateWifiControl($localityName, $siteCode, $location, $sitename, $contractstatus, $endofContract, $cluster, $tenderCode, $category, $sitetype);

    var_dump($update->updateAttr());
}
