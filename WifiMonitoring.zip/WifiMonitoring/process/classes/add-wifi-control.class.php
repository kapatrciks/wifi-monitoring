<?php
class AddWifiControl extends ViewWifi
{

    private $site_data;

    public function __construct($site_data)
    {
        $this->site_data = $site_data;
    }

    public function addAttr()
    {

        $this->checkEmpty();
        $this->duplicateInput();


        $this->insertWifiSite($this->site_data);

        header('location: ../WifiData.php?insert=success');
        exit();
    }

    public function checkEmpty()
    {

        foreach ($this->site_data['Locality_name'] as $val => $key) {

            if (empty($this->site_data['Locality_name'][$val])) {
                header('location: ../AddWifi.php?error=empty');
                exit();
            }
        }
        foreach ($this->site_data['Site_code'] as $val => $key) {

            if (empty($this->site_data['Site_code'][$val])) {
                header('location: ../AddWifi.php?error=empty');
                exit();
            }
        }
        foreach ($this->site_data['Wifi_Location'] as $val => $key) {

            if (empty($this->site_data['Wifi_Location'][$val])) {
                header('location: ../AddWifi.php?error=empty');
                exit();
            }
        }
        foreach ($this->site_data['Site_name'] as $val => $key) {

            if (empty($this->site_data['Site_name'][$val])) {
                header('location: ../AddWifi.php?error=empty');
                exit();
            }
        }
        foreach ($this->site_data['Longitude'] as $val => $key) {

            if (empty($this->site_data['Longitude'][$val])) {
                header('location: ../AddWifi.php?error=empty');
                exit();
            }
        }
        foreach ($this->site_data['Latitude'] as $val => $key) {

            if (empty($this->site_data['Latitude'][$val])) {
                header('location: ../AddWifi.php?error=empty');
                exit();
            }
        }
        foreach ($this->site_data['Contract_status'] as $val => $key) {

            if (empty($this->site_data['Contract_status'][$val])) {
                header('location: ../AddWifi.php?error=empty');
                exit();
            }
        }
        // foreach ($this->site_data['Integrated_date'] as $val => $key) {

        //     if (empty($this->site_data['Integrated_date'][$val])) {
        //                 header('location: ../AddWifi.php?error=empty');
        // exit();


        //     }
        // }
        foreach ($this->site_data['Cluster'] as $val => $key) {

            if (empty($this->site_data['Cluster'][$val])) {
                header('location: ../AddWifi.php?error=empty');
                exit();
            }
        }
        foreach ($this->site_data['Tender_code'] as $val => $key) {

            if (empty($this->site_data['Tender_code'][$val])) {
                header('location: ../AddWifi.php?error=empty');
                exit();
            }
        }
        foreach ($this->site_data['Category'] as $val => $key) {

            if (empty($this->site_data['Category'][$val])) {
                header('location: ../AddWifi.php?error=empty');
                exit();
            }
        }
        foreach ($this->site_data['Site_type'] as $val => $key) {

            if (empty($this->site_data['Site_type'][$val])) {
                header('location: ../AddWifi.php?error=empty');
                exit();
            }
        }

        return true;
    }

    public function duplicateInput()
    {
        $coordinates = [];

        foreach ($this->site_data['Longitude'] as $val => $key) {

            $coordinates[] = $this->site_data['Longitude'][$val] . '^' . $this->site_data['Latitude'][$val];
        }

        $count = count($this->site_data['Longitude']);

        $validate = array_unique($coordinates);
        $countvalidate = count($validate);

        if ($count != $countvalidate) {
            header('location: ../AddWifi.php?error=duplicatecoor');
            exit();
        }

        $this->validateData($this->site_data);

        return true;
    }
}
