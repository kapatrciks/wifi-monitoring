<?php

class ViewWifi extends Model
{
    public function collectWifi()
    {
        $stmt = $this->connect()->prepare('SELECT * FROM wifi_data');

        $stmt->execute();

        return $stmt;
    }

    public function searchWifi($data)
    {

        $val = $data . '%';
        $stmt = $this->connect()->prepare('SELECT * FROM wifi_data WHERE (SITENAME LIKE :SITENAME) OR (LOCATION LIKE :locaten)');

        $stmt->bindParam(':SITENAME', $val);
        $stmt->bindParam(':locaten', $val);

        $stmt->execute();

        return $stmt;
    }

    public function validateData($data)
    {
        foreach ($data['Longitude'] as $val => $key) {
            $stmt = $this->connect()->prepare('SELECT Longitude, Latitude FROM wifi_data WHERE (Longitude = :Longitude) AND (Latitude = :Latitude)');

            $stmt->bindParam(':Longitude', $data['Longitude'][$val]);
            $stmt->bindParam(':Latitude', $data['Latitude'][$val]);

            $stmt->execute();

            if ($stmt->rowCount() != 0) {
                header('location: ../AddWifi.php?error=existcoor&form=' . ($val + 1));
                exit();
            }
            return true;
        }
    }

    public function insertWifiSite($wifi_site_data)
    {

        // return $wifi_site_data;
        $integrated_date =  date('Y-m-d');

        // $num = [];

        foreach ($wifi_site_data['Site_name'] as $val => $key) {
            // $num[] =  $val;
            // return $wifi_site_data['Wifi_Location'][$val];
            // return $integrated_date;


            $stmt = $this->connect()->prepare('INSERT INTO wifi_data(`Locality Name`, `SITE CODE`, `LOCATION`, `SITENAME`, `Longitude`, `Latitude`, `CONTRACT STATUS`, `INTEGRATED DATE`, `Cluster`, `CMS TENDER CODE`, `CATEGORY`, `SITE TYPE`) VALUES(:Locality_name, :Site_code, :Wifi_Location, :Site_name, :Longitude, :Latitude, :Contract_status, :integrated_date, :Cluster, :Tender_code, :Category, :Site_type)');

            $stmt->bindParam(':Locality_name', $wifi_site_data['Locality_name'][$val]);
            $stmt->bindParam(':Site_code', $wifi_site_data['Site_code'][$val]);
            $stmt->bindParam(':Wifi_Location', $wifi_site_data['Wifi_Location'][$val]);
            $stmt->bindParam(':Site_name', $wifi_site_data['Site_name'][$val]);
            $stmt->bindParam(':Longitude', $wifi_site_data['Longitude'][$val]);
            $stmt->bindParam(':Latitude', $wifi_site_data['Latitude'][$val]);
            $stmt->bindParam(':Contract_status', $wifi_site_data['Contract_status'][$val]);
            $stmt->bindParam(':integrated_date', $integrated_date);
            $stmt->bindParam(':Cluster', $wifi_site_data['Cluster'][$val]);
            $stmt->bindParam(':Tender_code', $wifi_site_data['Tender_code'][$val]);
            $stmt->bindParam(':Category', $wifi_site_data['Category'][$val]);
            $stmt->bindParam(':Site_type', $wifi_site_data['Site_type'][$val]);

            $stmt->execute();
        }

        $stmt = null;
        return $stmt;
    }

    public function delData($long, $lat)
    {

        // return $long;
        // return $lat;

        foreach ($long as $val => $key) {

            // return $long[$val];  

            $stmt = $this->connect()->prepare('DELETE FROM `wifi_data` WHERE (Longitude = :Longitude) AND (Latitude = :Latitude)');

            $stmt->bindParam(':Longitude', $long[$val]);
            $stmt->bindParam(':Latitude', $lat[$val]);

            if (!$stmt->execute()) {
                header('location: ../WifiData.php');
                exit();
            }
        }
        return null;
    }

    public function longLatDataView($long, $lat)
    {
        $stmt = $this->connect()->prepare("SELECT * FROM wifi_data WHERE (Longitude = :Longitude) AND (Latitude = :Latitude)");

        $stmt->bindParam(':Longitude', $long);
        $stmt->bindParam(':Latitude', $lat);

        $stmt->execute();

        return $stmt;
    }

    public function updateWifiSite($localityName, $siteCode, $location, $sitename, $contractstatus, $endofContract, $cluster, $tenderCode, $category, $sitetype)
    {
        session_start();
        $long = $_SESSION['Longitude'];
        $lat = $_SESSION['Latitude'];

        $stmt = $this->connect()->prepare('UPDATE wifi_data SET `Locality Name`= :localityName,`SITE CODE`=:siteCode,`LOCATION`=:location,`SITENAME`=:sitename,`CONTRACT STATUS`=:contractstatus,`END OF CONTRACT`=:endofContract,`Cluster`=:cluster,`CMS TENDER CODE`=:tenderCode,`CATEGORY`=:category,`SITE TYPE`=:sitetype WHERE (Longitude = :Longitude) AND (Latitude = :Latitude)');

        $stmt->bindParam(':localityName', $localityName);
        $stmt->bindParam(':siteCode', $siteCode);
        $stmt->bindParam(':location', $location);
        $stmt->bindParam(':sitename', $sitename);
        $stmt->bindParam(':contractstatus', $contractstatus);
        $stmt->bindParam(':endofContract', $endofContract);
        $stmt->bindParam(':cluster', $cluster);
        $stmt->bindParam(':tenderCode', $tenderCode);
        $stmt->bindParam(':category', $category);
        $stmt->bindParam(':sitetype', $sitetype);

        // Coordinates na nagsisilibing ID
        $stmt->bindParam(':Longitude', $long);
        $stmt->bindParam(':Latitude', $lat);

        if (!$stmt->execute()) {
            header('location: ../WifiData.php');
            exit();
        }

        $stmt = null;

        return true;
    }
}
