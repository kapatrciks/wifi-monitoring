<?php
class DelControl extends ViewWifi
{
    private $longLat;
    private $longitude;
    private $latitude;

    public function __construct($longLat)
    {
        $this->longLat = $longLat;
    }

    public function deleteData()
    {
        $this->checkData();


        $this->delData($this->longitude, $this->latitude);

        header('location: ../WifiData.php?success=delete');
        exit();
    }

    public function checkData()
    {
        $data = [
            "x" => array(),
            "y" => array()
        ];
        foreach ($this->longLat as $val => $key) {
            if (empty($this->longLat[$val])) {
                header('location: ../WifiData.php');
            }

            $explode = explode('/', $this->longLat[$val]);

            $data['x'][] = $explode[0];
            $data['y'][] = $explode[1];
        }

        foreach ($data["x"] as $val => $key) {
            if (empty($data["x"][$val])) {
                header('location: ../WifiData.php?emptyx');
            }
        }

        foreach ($data["y"] as $val => $key) {
            if (empty($data["y"][$val])) {
                header('location: ../WifiData.php?emptyy');
            }
        }

        foreach ($data["x"] as $val => $key) {
            if (!preg_match('/\d/', $data["x"][$val])) {
                header('location: ../WifiData.php?invalidx');
            }
        }

        foreach ($data["y"] as $val => $key) {
            if (!preg_match('/\d/', $data["y"][$val])) {
                header('location: ../WifiData.php?invalidy');
            }
        }

        $this->longitude = $data['x'];
        $this->latitude = $data['y'];
        return true;
    }
}
