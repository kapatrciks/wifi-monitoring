<?php

class ViewAdmin extends Model
{
    public function viewAdmin()
    {
        $stmt = $this->connect()->prepare('SELECT * FROM admin');

        $stmt->execute();

        return $stmt;
    }

    public function callAdmin($admin_id)
    {

        $stmt = $this->connect()->prepare('SELECT * FROM admin WHERE `admin_id` = :admin_id');

        $stmt->bindParam(':admin_id', $admin_id);

        $stmt->execute();

        return $stmt;
    }

    public function delAdminData($admindata)
    {
        foreach ($admindata as $val => $key) {
            $stmt = $this->connect()->prepare('DELETE FROM `admin` WHERE `admin_id` = :admin_id');

            $stmt->bindParam(':admin_id', $admindata[$val]);

            $stmt->execute();

            $stmt = null;
        }

        return null;
    }
}
