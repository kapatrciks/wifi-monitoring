<?php
class LoginView extends Model
{
    public function validateUser($username, $password)
    {

        $stmt = $this->connect()->prepare('SELECT admin_id, admin_password FROM admin WHERE admin_uname = :admin_uname');

        $stmt->bindParam(':admin_uname', $username);

        $stmt->execute();

        $data = $stmt->fetch();

        if ($stmt->rowCount() == 0) {
            header('location: ../WifiMonitoring.php?error=nouser');
            exit();
        }




        if (!password_verify($password, $data['admin_password'])) {
            header('location: ../WifiMonitoring.php?error=notvalidpword');
            exit();
        } else {
            $stmt = $this->connect()->prepare('SELECT * FROM admin WHERE admin_id = :admin_id');

            $stmt->bindParam(':admin_id', $data['admin_id']);

            $stmt->execute();

            $admin_data = $stmt->fetch();

            session_start();
            $_SESSION['admin_id'] = $admin_data['admin_id'];
            $_SESSION['admin_fname'] = $admin_data['admin_fname'];
            $_SESSION['admin_lname'] = $admin_data['admin_lname'];
            $_SESSION['admin_uname'] = $admin_data['admin_uname'];
            $_SESSION['admin_password'] = $admin_data['admin_password'];

            header('location: ../Dashboard.php');
        }
    }
}
