<?php
class AdminDelControl extends ViewAdmin
{

    private $delAdmin;

    public function __construct($delAdmin)
    {
        $this->delAdmin = $delAdmin;
    }

    public function delAttr()
    {
        $this->emptyAdmin();
        $this->regexAdmin();

        $this->delAdminData($this->delAdmin);

        header('location: ../WifiData.php?success=delete');
        exit();
    }

    public function emptyAdmin()
    {

        foreach ($this->delAdmin as $val => $key) {
            if (empty($this->delAdmin[$val])) {
                header('location: ../WifiData.php');
                exit();
            }
        }
        return true;
    }

    public function regexAdmin()
    {

        foreach ($this->delAdmin as $val => $key) {
            if (!preg_match('/\d/', $this->delAdmin[$val])) {
                header('location: ../WifiData.php');
                exit();
            }
        }
        return true;
    }
}
