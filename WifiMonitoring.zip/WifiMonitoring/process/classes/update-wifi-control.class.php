<?php
class UpdateWifiControl extends ViewWifi
{
    private $localityName;
    private $siteCode;
    private $location;
    private $sitename;
    private $contractstatus;
    private $endofContract;
    private $cluster;
    private $tenderCode;
    private $category;
    private $sitetype;
    public function __construct($localityName, $siteCode, $location, $sitename, $contractstatus, $endofContract, $cluster, $tenderCode, $category, $sitetype)
    {
        $this->localityName = $localityName;
        $this->siteCode = $siteCode;
        $this->location = $location;
        $this->sitename = $sitename;
        $this->contractstatus = $contractstatus;
        $this->endofContract = $endofContract;
        $this->cluster = $cluster;
        $this->tenderCode = $tenderCode;
        $this->category = $category;
        $this->sitetype = $sitetype;
    }

    public function updateAttr()
    {
        $this->checkEmpty();

        $this->updateWifiSite($this->localityName, $this->siteCode, $this->location, $this->sitename, $this->contractstatus, $this->endofContract, $this->cluster, $this->tenderCode, $this->category, $this->sitetype);

        header('location: ../WifiInfo.php?success=update');
        exit();
    }

    public function checkEmpty()
    {
        if (empty($this->localityName)) {
            header('location: ../WifiInfo.php?empty=localityName');
            exit();
        }
        if (empty($this->siteCode)) {
            header('location: ../WifiInfo.php?empty=siteCode');
            exit();
        }
        if (empty($this->location)) {
            header('location: ../WifiInfo.php?empty=location');
            exit();
        }
        if (empty($this->sitename)) {
            header('location: ../WifiInfo.php?empty=sitename');
            exit();
        }
        if (empty($this->contractstatus)) {
            header('location: ../WifiInfo.php?empty=contractstatus');
            exit();
        }
        // optional self
        // if (empty($this->endofContract)) {
        //     header('location: ../WifiInfo.php?empty=endofContract');
        //     exit();
        // }

        if (empty($this->cluster)) {
            header('location: ../WifiInfo.php?empty=cluster');
            exit();
        }
        if (empty($this->tenderCode)) {
            header('location: ../WifiInfo.php?empty=tenderCode');
            exit();
        }
        if (empty($this->category)) {
            header('location: ../WifiInfo.php?empty=category');
            exit();
        }
        if (empty($this->sitetype)) {
            header('location: ../WifiInfo.php?empty=sitetype');
            exit();
        }
        return true;
    }
}
