<?php
class LoginControl extends LoginView
{
    private $username;
    private $password;

    public function __construct($username, $password)
    {
        $this->username = $username;
        $this->password = $password;
    }

    public function loginAttr()
    {
        $this->checkEmpty();
        $this->checkRegex();

        return $this->validateUser($this->username, $this->password);
    }

    public  function checkEmpty()
    {
        if (empty($this->username)) {
            header('location: ../WifiMonitoring.php?empty=uname');
            exit();
        }
        if (empty($this->password)) {
            header('location: ../WifiMonitoring.php?empty=pword');
            exit();
        }
        return true;
    }

    public function checkRegex()
    {
        if (preg_match('/^[a-zA-Z0-9]$/', $this->username)) {
            header('location: ../WifiMonitoring.php?invalid=uname');
            exit();
        }
        if (!preg_match('/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^\w\d\s]).{8,}$/', $this->password)) {
            header('location: ../WifiMonitoring.php?invalid=pword');
            exit();
        }
        return true;
    }
}
