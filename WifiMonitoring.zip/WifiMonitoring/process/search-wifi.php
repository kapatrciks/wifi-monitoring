<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['search'])) {
        $data = '';
    } else {
        $data = htmlspecialchars($_POST['search']);
    }


    include 'classes/model.class.php';
    include 'classes/view-wifi.class.php';

    $wifi_info = new ViewWifi();
    $wifi_data = $wifi_info->collectWifi();
    $search = $wifi_info->searchWifi($data);

?>
    <table>
        <tr>
            <th>Sitename</th>
            <th>Location</th>
            <th>Status</th>
            <th></th>
        </tr>
        <?php

        if ($search->rowCount() != 0) {
            while ($row = $search->fetch()) {
        ?>
                <tr>
                    <td>
                        <?php echo $row['SITENAME'] ?>
                    </td>
                    <td><?php echo $row['LOCATION'] ?></td>
                    <td>
                        <div class="content-status <?php
                                                    if (strtolower($row['CONTRACT STATUS']) == 'active') {
                                                        echo "status-active";
                                                    }
                                                    ?>">
                            <?php echo $row['CONTRACT STATUS'] ?>
                        </div>
                    </td>
                    <td>
                        <button type="button" class="view-btn" id="<?php echo $row['SITENAME'] ?>">view</button>
                        <script>
                            document.getElementById('<?php echo $row['SITENAME'] ?>').addEventListener('click', () => {
                                map.flyTo({
                                    center: [<?php echo $row['Latitude'] ?>, <?php echo $row['Longitude'] ?>],
                                    zoom: 15,
                                })
                            });
                        </script>
                    </td>
                </tr>
            <?php
            }
        } else {
            ?>
            <tr>
                <td id="nodata" colspan="4">
                    No data result...
                </td>
            </tr>
        <?php
        }

        ?>
    </table>
<?php
}

?>