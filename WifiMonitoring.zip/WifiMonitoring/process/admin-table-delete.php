<?php

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    include 'classes/model.class.php';
    include 'classes/admin-list-view.class.php';

    $adminRecord = new ViewAdmin();

    $adminList = $adminRecord->viewAdmin();
?>

    <form action="process/deladmin.php" method="post">
        <table class = "t_table">
            <tr>
                <td>
                    <div class="admin-content">
                        <input type="checkbox" id="check-all" onchange="checkAll(this)">
                        <label for="check-all">Select all</label>
                    </div>
                </td>
                <th>Admin Name</th>
                <th>Username</th>
            </tr>
            <?php
            if ($adminList->rowCount() != 0) {
                while ($row = $adminList->fetch()) {
                    if ($row['admin_id'] != 1) {
            ?>
                        <tr>
                            <td><input type="checkbox" name="del-admin[]" id="" value="<?php echo $row['admin_id'] ?>"></td>
                            <td><?php echo ucfirst($row['admin_fname']) . ' ' . ucfirst($row['admin_lname']);; ?></td>
                            <td><?php echo $row['admin_uname'] ?></td>
                        </tr    >
                <?php
                    }
                }
            } else {
                ?>
                <tr>
                    <td colspan="3">No admin result...</td>
                </tr>
            <?php
            }
            ?>
        </table>
        <div class="del-admin-btn">
            <input type="submit" value="Delete">
        </div>
    </form>
    <script src="javascript/checkbox.js"></script>

<?php

}
