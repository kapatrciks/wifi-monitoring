<?php
if ($_SERVER['REQUEST_METHOD'] === "POST") {

    if (!isset($_POST['localityname'])) {
        header('location: ../AddWifi.php?error=notset');
        exit();
    }
    if (!isset($_POST['sitecode'])) {
        header('location: ../AddWifi.php?error=notset');
        exit();
    }
    if (!isset($_POST['location'])) {
        header('location: ../AddWifi.php?error=notset');
        exit();
    }
    if (!isset($_POST['sitename'])) {
        header('location: ../AddWifi.php?error=notset');
        exit();
    }
    if (!isset($_POST['longitude'])) {
        header('location: ../AddWifi.php?error=notset');
        exit();
    }
    if (!isset($_POST['latitude'])) {
        header('location: ../AddWifi.php?error=notset');
        exit();
    }
    if (!isset($_POST['contractstatus'])) {
        header('location: ../AddWifi.php?error=notset');
        exit();
    }
    if (!isset($_POST['cluster'])) {
        header('location: ../AddWifi.php?error=notset');
        exit();
    }
    if (!isset($_POST['tendercode'])) {
        header('location: ../AddWifi.php?error=notset');
        exit();
    }
    if (!isset($_POST['category'])) {
        header('location: ../AddWifi.php?error=notset');
        exit();
    }
    if (!isset($_POST['sitetype'])) {
        header('location: ../AddWifi.php?error=notset');
        exit();
    }

    $site_data = [
        "Locality_name" => array(),
        "Site_code" => array(),
        "Wifi_Location" => array(),
        "Site_name" => array(),
        "Longitude" => array(),
        "Latitude" => array(),
        "Contract_status" => array(),
        // "Integrated_date" => array(),
        "Cluster" => array(),
        "Tender_code" => array(),
        "Category" => array(),
        "Site_type" => array(),
    ];

    foreach ($_POST['localityname'] as $val => $key) {
        $site_data["Locality_name"][] = filter_var($_POST['localityname'][$val], FILTER_SANITIZE_STRING);
    }
    foreach ($_POST['sitecode'] as $val => $key) {
        $site_data["Site_code"][] = filter_var($_POST['sitecode'][$val], FILTER_SANITIZE_STRING);
    }

    foreach ($_POST['location'] as $val => $key) {
        $site_data["Wifi_Location"][] = filter_var($_POST['location'][$val], FILTER_SANITIZE_STRING);
    }

    foreach ($_POST['sitename'] as $val => $key) {
        $site_data["Site_name"][] = filter_var($_POST['sitename'][$val], FILTER_SANITIZE_STRING);
    }

    foreach ($_POST['longitude'] as $val => $key) {
        $site_data["Longitude"][] = filter_var($_POST['longitude'][$val], FILTER_SANITIZE_STRING);
    }

    foreach ($_POST['latitude'] as $val => $key) {
        $site_data["Latitude"][] = filter_var($_POST['latitude'][$val], FILTER_SANITIZE_STRING);
    }

    foreach ($_POST['contractstatus'] as $val => $key) {
        $site_data["Contract_status"][] = filter_var($_POST['contractstatus'][$val], FILTER_SANITIZE_STRING);
    }

    // foreach ($_POST['integrateddate'] as $val => $key) {
    //     $site_data["Integrated_date"][] = filter_var($_POST['integrateddate'][$val], FILTER_SANITIZE_STRING);
    // }
    foreach ($_POST['cluster'] as $val => $key) {
        $site_data["Cluster"][] = filter_var($_POST['cluster'][$val], FILTER_SANITIZE_STRING);
    }
    foreach ($_POST['tendercode'] as $val => $key) {
        $site_data["Tender_code"][] = filter_var($_POST['tendercode'][$val], FILTER_SANITIZE_STRING);
    }
    foreach ($_POST['category'] as $val => $key) {
        $site_data["Category"][] = filter_var($_POST['category'][$val], FILTER_SANITIZE_STRING);
    }
    foreach ($_POST['sitetype'] as $val => $key) {
        $site_data["Site_type"][] = filter_var($_POST['sitetype'][$val], FILTER_SANITIZE_STRING);
    }


    session_start();
    $_SESSION['site_data'] = $site_data;

    include 'classes/model.class.php';
    include 'classes/view-wifi.class.php';
    include 'classes/add-wifi-control.class.php';

    $insert_site_data = new AddWifiControl($site_data);

    var_dump($insert_site_data->addAttr());
    // $insert_site_data->addAttr();
}
