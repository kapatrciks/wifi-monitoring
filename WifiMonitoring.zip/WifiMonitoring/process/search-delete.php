<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if (!isset($_POST['data'])) {
        $data = '';
    } else {
        $data = htmlspecialchars($_POST['data']);
    }




    include 'classes/model.class.php';
    include 'classes/view-wifi.class.php';

    $wifi_info = new ViewWifi();
    $wifi_data = $wifi_info->collectWifi();
    $search = $wifi_info->searchWifi($data);

?>
    <table>
        <tr>
            <th class="check-b table-head">
                <div class="select-content">
                    <input type="checkbox" id="check-all" onchange="checkAll(this)">
                    <label for="check-all">Select all</label>
                </div>
            </th>
            <th class="table-head">Sitename</th>
            <th class="table-head">Location</th>
            <th class="table-head">Locality name</th>
        </tr>

        <?php
        if ($search->rowCount() != 0) {
            while ($row = $search->fetch()) {
        ?>
                <tr>
                    <td class="check-b"><input type="checkbox" name="del-wifi[]" id="" value="<?php echo $row['Longitude'] . '/' . $row['Latitude']; ?>"></td>
                    <td>
                        <?php echo $row['SITENAME'] ?>
                    </td>
                    <td><?php echo $row['LOCATION'] ?></td>
                    <td>
                        <?php echo $row['Locality Name'] ?>
                    </td>
                </tr>
            <?php
            }
        } else {
            ?>
            <tr>
                <td colspan="4">
                    No data result...
                </td>
            </tr>
        <?php
        }
        ?>


    </table>
    <script src="javascript/checkbox.js"></script>
<?php
}
