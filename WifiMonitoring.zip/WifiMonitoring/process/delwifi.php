<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // echo '<pre>';
    // var_dump($_POST['del-wifi']);
    // echo '</pre>';

    if (!isset($_POST['del-wifi'])) {
        header('location: ../WifiData.php');
        exit();
    }

    $delWifi = [];

    foreach ($_POST['del-wifi'] as $val => $key) {
        $delWifi[] = filter_var($_POST['del-wifi'][$val], FILTER_SANITIZE_STRING);
    }

    include 'classes/model.class.php';
    include 'classes/view-wifi.class.php';
    include 'classes/del-wifi-control.class.php';

    $del = new DelControl($delWifi);

    $del->deleteData();
}






// 900000
// Supra
// Admin
// SuperAdmin
// $2y$10$oJHvVb4YQ0cJHAE0pkxfbu4yku/klWAOpjEmqRFl0HRLUoVB2V5tC
