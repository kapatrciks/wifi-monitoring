<?php
if ($_SERVER['REQUEST_METHOD']) {

    if (!isset($_POST['del-admin'])) {
        header('location: ../AdminManagement.php');
        exit();
    }

    $admindata = [];
    foreach ($_POST['del-admin'] as $val => $key) {

        $admindata[] = filter_var($_POST['del-admin'][$val], FILTER_SANITIZE_NUMBER_INT);
    }
    // var_dump($admindata);


    include 'classes/model.class.php';
    include 'classes/admin-list-view.class.php';
    include 'classes/admin-del-control.class.php';

    $deladmin = new AdminDelControl($admindata);

    var_dump($deladmin->delAttr());
}
