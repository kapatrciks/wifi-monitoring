<?php
session_start();
if (empty($_SESSION['admin_id'])) {
    header('Location: WifiMonitoring.php');
}

// echo password_hash('JamesBond26!', PASSWORD_DEFAULT);

include 'process/classes/model.class.php';
include 'process/classes/view-wifi.class.php';

$data = new ViewWifi();

$wifireport = $data->collectWifi();





?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js" integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <link rel="stylesheet" href="css/sidenav.css">
    <link rel="stylesheet" href="css/admin.css">
    <link rel="stylesheet" href="css/adminMan.css">


</head>

<body>
    <div class="admin-container">
        <div class="navcontainer">
            <?php
            include 'include/sidenav.php';;
            ?>
        </div>


        <div class="main-admin">

            <div class="adim-header">
                <h1>Admin Management</h1>
            </div>
            <div id="successContainer" id="successContainer">
                <p>Successfully Updated!</p>
            </div>


            <div class="admin-body">
                <div class="admin-btn">
                    <button type="button" id="admin-del" class="del">
                        <i class="fa-solid fa-user-slash"></i> Delete
                    </button>
                    <button type="button" class="edit_btn" id="admin-edit" style="display: none;">
                        <i class="fa-solid fa-user-pen"></i> Edit
                    </button>
                    <button href="admin_account.php" class="admin-add" id="add-admin"><i class="fa-solid fa-user-plus"></i>Add</button>
                </div>
                <div class="content">

                    <div id="admin-list"></div>
                </div>

            </div>
        </div>
    </div>



    </div>
    <div class="background-hider" style="display: none;">
        <div class="container">
            <div class="body-content">

                <div class="header-add-admin">
                    <h1>Admin Management</h1>
                    <button type="button" id="exit-add"><i class="fa-solid fa-xmark"></i></button>
                </div>
            </div>



            <form action="process/insert-data/formhandler.inc.php" method="POST" onsubmit="generateCredentials()">
                <div class="formFirst">
                    <div class="personalDetails">
                        <span class="title">Personal Details</span>

                        <div class="fields">
                            <div class="inputField">
                                <label>First Name</label>
                                <input type="text" name="firstname" placeholder="Enter FirstName" required>
                            </div>

                            <div class="inputField">
                                <label>Last Name</label>
                                <input type="text" name="lastname" placeholder="Enter LastName" required>
                            </div>

                            <div class="inputField">
                                <label>Position</label>
                                <input type="text" name="position" placeholder="Enter Position" required>
                            </div>
                            <div class="generateBtn">
                                <button type="button" onclick="generateCredentials()">Generate Account</button>
                            </div>
                        </div>
                    </div>

                    <!-- ---Generated Account------>

                    <div class="generated">
                        <span class="title">Generated Account</span>

                        <div class="generate-fields">
                            <div class="inputField">
                                <label>Username</label>
                                <input type="text" name="username" readonly>

                                <label>Password</label>
                                <input type="text" name="password" readonly>
                            </div>
                        </div>
                    </div>

                </div>
                <div class="createBtn">
                    <input type="submit" value="Create Account">
                </div>

            </form>
        </div>


    </div>
    <script src="javascript/register.js"></script>

</body>



<script>
    $(document).ready(function() {
        $.ajax({
            url: 'process/admin-table-edit.php',
            method: 'POST',
            success: function(admin) {
                $('#admin-list').html(admin);
            }
        })

        $('#admin-del').click(function() {
            $(this).css('display', 'none');
            $('#admin-edit').fadeIn(300);

            $.ajax({
                url: 'process/admin-table-delete.php',
                method: 'POST',
                success: function(admin) {
                    $('#admin-list').html(admin);
                }
            })
        });

        $('#admin-edit').click(function() {
            $(this).css('display', 'none');
            $('#admin-del').fadeIn(300);

            $.ajax({
                url: 'process/admin-table-edit.php',
                method: 'POST',
                success: function(admin) {
                    $('#admin-list').html(admin);
                }
            })
        });

        $('#exit-add').click(function() {
            $('.background-hider').css('display', 'none');

        });

        $('#add-admin').click(function() {
            $('.background-hider').fadeIn(300);

        });




    });
</script>




</html>