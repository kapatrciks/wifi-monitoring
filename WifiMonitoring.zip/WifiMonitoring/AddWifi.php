<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js" integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <link rel="stylesheet" href="css/sidenav.css">
    <link rel="stylesheet" href="css/addwifi.css">

</head>

<body>
    <div class="add-wifi-container">
        <div class="navcontainer">
            <?php
            include 'include/sidenav.php';
            ?>
        </div>
        <div class="main-add-wifi">
            <div class="add-header">
                <a href="WifiData.php" class="back-btn"><i class="fa-solid fa-arrow-left"></i></a>
            </div>
            <div class="add-container">

                <div class="header-input-add">
                    <h1>Add Wifi Location</h1>

                    <button type="button" id="add-data"><i class="fa-solid fa-plus"></i></button>
                </div>
                <div id="data-inout-add">
                    <form action="process/addwifi.php" method="post">
                        <table id="input-data">
                            <tr>
                                <td>
                                    <div class="input-data">
                                        <div class="remove-btn">
                                            <button type="button" class="remove-id"><i class="fa-solid fa-xmark"></i></button>
                                        </div>
                                        <div class="input-form">
                                            <label>Locality Name</label>
                                            <input type="text" name="localityname[]">
                                        </div>
                                        <div class="input-form">
                                            <label>Site Code</label>
                                            <input type="text" name="sitecode[]">
                                        </div>
                                        <div class="input-form">
                                            <label>Location</label>
                                            <input type="text" name="location[]">
                                        </div>
                                        <div class="input-form">
                                            <label>Site name</label>
                                            <input type="text" name="sitename[]">
                                        </div>
                                        <div class="input-form">
                                            <label for="">Coordinates:</label>
                                            <div class="coordinates">
                                                <div class="long-input input-form">
                                                    <label>Longitude</label>
                                                    <input type="text" name="longitude[]">
                                                </div>
                                                <div class="lat-input input-form">
                                                    <label>Latitude</label>
                                                    <input type="text" name="latitude[]">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="input-form">
                                            <label>Contract Status</label>
                                            <input type="text" name="contractstatus[]">
                                        </div>
                                        <!-- <div class="input-form">
                                            <label>Integrated Date</label>
                                            <input type="date" name="integrateddate[]">
                                        </div> -->
                                        <div class="input-form">
                                            <label>Cluster</label>
                                            <input type="text" name="cluster[]">
                                        </div>
                                        <div class="input-form">
                                            <label>CMS Tender Code</label>
                                            <input type="text" name="tendercode[]">
                                        </div>
                                        <div class="input-form">
                                            <label>Category</label>
                                            <input type="text" name="category[]">
                                        </div>
                                        <div class="input-form">
                                            <label>Site type</label>
                                            <input type="text" name="sitetype[]">
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        </table>
                        <div class="wifi-proceed">
                            <input type="submit" value="proceed">
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <script>
        $(document).ready(function() {
            var x = 1,
                y = 10;

            $('#add-data').click(function() {
                var htmlForm = `<tr>
                                    <td>
                                        <div class="input-data">
                                            <div class="remove-btn">
                                                <button type="button" class="remove-id"><i class="fa-solid fa-xmark"></i></button>
                                            </div>
                                            <div class="input-form">
                                                <label>Locality Name</label>
                                                <input type="text" name="localityname[]">
                                            </div>
                                            <div class="input-form">
                                                <label>Site Code</label>
                                                <input type="text" name="sitecode[]">
                                            </div>
                                            <div class="input-form">
                                                <label>Location</label>
                                                <input type="text" name="location[]">
                                            </div>
                                            <div class="input-form">
                                                <label>Site name</label>
                                                <input type="text" name="sitename[]">
                                            </div>
                                            <div class="input-form">
                                                <label for="">Coordinates:</label>
                                                <div class="coordinates">
                                                    <div class="long-input ">
                                                        <label>Longitude</label>
                                                        <input type="text" name="longitude[]">
                                                    </div>
                                                    <div class="lat-input ">
                                                        <label>Latitude</label>
                                                        <input type="text" name="latitude[]">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="input-form">
                                                <label>Contract Status</label>
                                                <input type="text" name="contractstatus[]">
                                            </div>
                                            <div class="input-form">
                                                <label>Cluster</label>
                                                <input type="text" name="cluster[]">
                                            </div>
                                            <div class="input-form">
                                                <label>CMS Tender Code</label>
                                                <input type="text" name="tendercode[]">
                                            </div>
                                            <div class="input-form">
                                                <label>Category</label>
                                                <input type="text" name="category[]">
                                            </div>
                                            <div class="input-form">
                                                <label>Site type</label>
                                                <input type="text" name="sitetype[]">
                                            </div>
                                        </div>
                                    </td>
                                </tr>`;

                if (x < y) {
                    $('#input-data').append(htmlForm);

                    x++;
                    console.log(x);
                }
            });

            $('#input-data').on('click', '.remove-id', function() {
                $(this).closest("tr").remove();
                x--;

            });

        });
    </script>
</body>

</html>